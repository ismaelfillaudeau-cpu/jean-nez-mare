package com.allitemsop;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.RegisterEvent;

@Mod("allitemsop")
public class AllItemsOp {
    public AllItemsOp(IEventBus modBus) {
        modBus.addListener(AllItemsOp::onRegister);
        modBus.addListener(AllItemsOp::onTab);
    }

    private static void onRegister(RegisterEvent event) {
        event.register(Registries.ITEM, helper -> Common.registerBlockItems((id, item) -> helper.register(id, item)));
    }

    private static void onTab(BuildCreativeModeTabContentsEvent event) {
        if (!CreativeModeTabs.OP_BLOCKS.equals(event.getTabKey())) return;
        Common.fillTab(event::accept);
    }
}
