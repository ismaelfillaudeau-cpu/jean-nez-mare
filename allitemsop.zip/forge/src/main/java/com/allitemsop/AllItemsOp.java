package com.allitemsop;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegisterEvent;

@Mod("allitemsop")
public class AllItemsOp {
    public AllItemsOp() {
        var bus = FMLJavaModLoadingContext.get().getModEventBus();
        bus.addListener(AllItemsOp::onRegister);
        bus.addListener(AllItemsOp::onTab);
    }

    private static void onRegister(RegisterEvent event) {
        event.register(ForgeRegistries.Keys.ITEMS, helper -> Common.registerBlockItems((id, item) -> helper.register(id, item)));
    }

    private static void onTab(BuildCreativeModeTabContentsEvent event) {
        if (!CreativeModeTabs.OP_BLOCKS.equals(event.getTabKey())) return;
        Common.fillTab(event::accept);
    }
}
