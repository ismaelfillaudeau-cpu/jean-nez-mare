package com.allitemsop;

import java.util.HashSet;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.AirBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.MovingPistonBlock;

public final class Common {
    public static final String MODID = "allitemsop";

    private Common() {}

    /** Crée un BlockItem pour chaque bloc vanilla qui n'a aucun objet (feu, portails, eau, lave...). */
    public static void registerBlockItems(BiConsumer<ResourceLocation, Item> reg) {
        for (Block b : BuiltInRegistries.BLOCK) {
            ResourceLocation id = BuiltInRegistries.BLOCK.getKey(b);
            if (!"minecraft".equals(id.getNamespace())) continue;
            if (b.asItem() != Items.AIR) continue;
            if (b instanceof AirBlock || b instanceof MovingPistonBlock) continue;
            reg.accept(ResourceLocation.fromNamespaceAndPath(MODID, id.getPath()), new BlockItem(b, new Item.Properties()));
        }
    }

    /** Ajoute tous les objets absents des onglets créatifs normaux. */
    public static void fillTab(Consumer<Item> add) {
        Set<Item> seen = new HashSet<>();
        for (CreativeModeTab t : BuiltInRegistries.CREATIVE_MODE_TAB) {
            if (t.getType() != CreativeModeTab.Type.CATEGORY) continue;
            if (BuiltInRegistries.CREATIVE_MODE_TAB.getResourceKey(t).filter(CreativeModeTabs.OP_BLOCKS::equals).isPresent()) continue;
            for (ItemStack s : t.getDisplayItems()) seen.add(s.getItem());
        }
        for (Item i : BuiltInRegistries.ITEM) {
            if (i != Items.AIR && !seen.contains(i)) add.accept(i);
        }
    }
}
