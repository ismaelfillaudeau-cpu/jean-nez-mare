package com.allitemsop;

import java.util.HashSet;
import java.util.Set;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class AllItemsOp implements ModInitializer {
    @Override
    public void onInitialize() {
        Common.registerBlockItems((id, item) -> Registry.register(BuiltInRegistries.ITEM, id, item));
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.OP_BLOCKS).register(entries -> {
            Set<Item> present = new HashSet<>();
            for (ItemStack s : entries.getDisplayStacks()) present.add(s.getItem());
            Common.fillTab(i -> { if (!present.contains(i)) entries.accept(i); });
        });
    }
}
